import { Link } from 'react-router-dom';

const footerLinks = {
  buyers: {
    title: 'For Buyers',
    links: ['Browse Categories', 'How It Works', 'Buyer Protection', 'Success Stories'],
  },
  sellers: {
    title: 'For Sellers',
    links: ['List an Item', 'Seller Dashboard', 'Pricing Plans', 'Verification Process'],
  },
  company: {
    title: 'Company',
    links: ['About Us', 'Careers', 'Press', 'Contact'],
  },
};

export default function Footer() {
  return (
    <footer
      className="relative bg-gold z-[2] shadow-footer-glow"
      style={{
        borderRadius: '24px 24px 0 0',
        marginTop: '-24px',
      }}
    >
      <div className="max-w-[1280px] mx-auto px-6 pt-20 pb-10">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Brand */}
          <div>
            <Link to="/" className="font-display text-[24px] text-forest-dark">
              TradeLink
            </Link>
            <p className="font-body text-[14px] text-forest-dark/70 mt-3 leading-relaxed">
              The trusted marketplace for buyers and sellers worldwide.
            </p>
          </div>

          {/* Link columns */}
          {Object.values(footerLinks).map((col) => (
            <div key={col.title}>
              <h4 className="font-body text-[14px] font-semibold text-forest-dark uppercase tracking-[0.08em]">
                {col.title}
              </h4>
              <ul className="mt-4 space-y-2">
                {col.links.map((link) => (
                  <li key={link}>
                    <span className="font-body text-[14px] text-forest-dark/70 hover:text-forest-dark hover:underline transition-colors duration-200 cursor-default leading-[2.2]">
                      {link}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom bar */}
        <div className="mt-16 pt-6 border-t border-forest-dark/15 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="font-body text-[13px] text-forest-dark/50">
            &copy; 2025 TradeLink. All rights reserved.
          </p>
          <div className="flex items-center gap-4">
            {['X', 'in', 'IG', 'YT'].map((social) => (
              <span
                key={social}
                className="font-body text-[13px] font-semibold text-forest-dark/50 hover:text-forest-dark transition-colors duration-200 cursor-default w-5 h-5 flex items-center justify-center"
              >
                {social}
              </span>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
