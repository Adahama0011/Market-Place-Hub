import { trustedLogos } from '../data/deals';

export default function TrustedByBar() {
  return (
    <div className="relative z-10 w-full" style={{ background: 'rgba(26, 46, 26, 0.9)', backdropFilter: 'blur(8px)' }}>
      <div className="border-t border-b border-cream/[0.06] py-6">
        <p className="font-body text-[12px] uppercase tracking-[0.12em] text-sage text-center mb-4">
          Trusted by 10,000+ businesses worldwide
        </p>
        <div className="max-w-[1000px] mx-auto flex items-center justify-around px-6 flex-wrap gap-4">
          {trustedLogos.map((logo) => (
            <span
              key={logo}
              className="font-body text-[14px] font-semibold uppercase tracking-[0.06em] text-sage/50"
            >
              {logo}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}
