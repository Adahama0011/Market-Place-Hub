import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Smartphone, Home, Car, Shirt, Cpu, Briefcase } from 'lucide-react';
import { categories } from '../data/deals';

gsap.registerPlugin(ScrollTrigger);

const iconMap: Record<string, React.ReactNode> = {
  smartphone: <Smartphone size={22} />,
  home: <Home size={22} />,
  car: <Car size={22} />,
  shirt: <Shirt size={22} />,
  cpu: <Cpu size={22} />,
  briefcase: <Briefcase size={22} />,
};

export default function TrendingCategories() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    gsap.set(section, { opacity: 0, y: 40 });

    const trigger = ScrollTrigger.create({
      trigger: section,
      start: 'top 80%',
      end: 'top 40%',
      scrub: true,
      onUpdate: (self) => {
        gsap.to(section, {
          opacity: self.progress,
          y: 40 * (1 - self.progress),
          duration: 0,
        });
      },
    });

    return () => trigger.kill();
  }, []);

  return (
    <section
      id="categories"
      ref={sectionRef}
      className="relative z-10 min-h-screen flex flex-col items-center justify-center py-[120px] px-6"
      style={{
        background: 'rgba(13, 26, 13, 0.4)',
        backdropFilter: 'blur(2px)',
      }}
    >
      <div className="max-w-[1200px] w-full">
        <h2
          className="font-display text-cream text-center"
          style={{ fontSize: 'clamp(1.5rem, 3vw, 2.5rem)' }}
        >
          Trending Categories
        </h2>
        <div className="w-[60px] h-[2px] bg-gold mx-auto mt-4 mb-12" />

        <div ref={cardsRef} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {categories.map((cat) => (
            <div
              key={cat.name}
              className="glass-panel rounded-xl px-8 py-10 text-center group cursor-default hover:border-gold/40 hover:bg-forest-dark/80 hover:shadow-glass transition-all duration-300"
            >
              <div className="w-12 h-12 rounded-full bg-emerald/30 flex items-center justify-center mx-auto text-cream/70">
                {iconMap[cat.icon]}
              </div>
              <h3 className="font-body text-[18px] font-semibold text-cream mt-5">
                {cat.name}
              </h3>
              <p className="font-mono text-[14px] text-sage mt-2">
                {cat.deals.toLocaleString()} active deals
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
