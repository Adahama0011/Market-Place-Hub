import { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import gsap from 'gsap';

export default function HeroSection() {
  const contentRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const content = contentRef.current;
    if (!content) return;

    gsap.set(content.children, { opacity: 0, y: 30 });
    gsap.to(content.children, {
      opacity: 1,
      y: 0,
      duration: 1,
      stagger: 0.15,
      ease: 'cubic-bezier(0.22, 1, 0.36, 1)',
      delay: 0.3,
    });
  }, []);

  useEffect(() => {
    const video = videoRef.current;
    const container = containerRef.current;
    if (!video || !container) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            video.play().catch(() => {});
          } else {
            video.pause();
          }
        });
      },
      { threshold: 0.1 }
    );

    observer.observe(container);
    return () => observer.disconnect();
  }, []);

  return (
    <section className="relative h-screen w-full overflow-hidden">
      {/* Fixed video background container */}
      <div ref={containerRef} className="absolute inset-0 z-0">
        <video
          ref={videoRef}
          autoPlay
          muted
          loop
          playsInline
          preload="auto"
          poster="/images/hero-poster.jpg"
          className="w-full h-full object-cover"
        >
          <source src="/videos/hero-bg.mp4" type="video/mp4" />
        </video>
        {/* Gradient blend to forest bg */}
        <div
          className="absolute bottom-0 left-0 right-0 h-[40%] pointer-events-none"
          style={{
            background: 'linear-gradient(to bottom, transparent 0%, #1A2E1A 100%)',
          }}
        />
      </div>

      {/* Hero content - bottom weighted */}
      <div
        ref={contentRef}
        className="absolute z-10 bottom-[15vh] left-1/2 -translate-x-1/2 max-w-[900px] w-full px-6 text-center"
      >
        <h1 className="font-display text-cream-bold text-shadow-hero leading-[1.1]" style={{ fontSize: 'clamp(2.5rem, 6vw, 5rem)', letterSpacing: '-0.02em' }}>
          <span className="block">Where Buyers Meet</span>
          <span className="block">
            Sellers Close<span className="text-gold">.</span>
          </span>
        </h1>

        <p className="font-body text-[18px] text-cream max-w-[560px] mx-auto mt-6 text-shadow-sub leading-relaxed">
          Discover verified deals across 200+ categories. From electronics to real estate — your next transaction starts here.
        </p>

        <div className="flex items-center justify-center gap-4 mt-10 flex-wrap">
          <Link
            to="/#featured"
            onClick={(e) => {
              e.preventDefault();
              document.getElementById('featured')?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="font-body font-semibold text-cream-bold bg-emerald px-9 py-3.5 rounded-[6px] text-[15px] tracking-[0.02em] hover:bg-emerald-light hover:shadow-btn-glow transition-all duration-300"
          >
            Browse Deals
          </Link>
          <span className="font-body font-semibold text-cream-bold border border-cream/40 px-9 py-3.5 rounded-[6px] text-[15px] tracking-[0.02em] hover:border-cream hover:bg-cream/[0.08] transition-all duration-300 cursor-default">
            List Your Item
          </span>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10">
        <div className="w-[2px] h-10 bg-cream/40 animate-scroll-pulse rounded-full" />
      </div>
    </section>
  );
}
