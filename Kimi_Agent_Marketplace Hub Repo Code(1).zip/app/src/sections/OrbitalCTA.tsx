import { useEffect, useRef, useState } from 'react';

const rings = [
  { className: 'w-[500px] h-[280px] -ml-[250px] -mt-[140px] animate-orbit-1', size: 'md:w-[500px] md:h-[280px] md:-ml-[250px] md:-mt-[140px] w-[300px] h-[170px] -ml-[150px] -mt-[85px]' },
  { className: 'w-[420px] h-[240px] -ml-[210px] -mt-[120px] animate-orbit-2', size: 'md:w-[420px] md:h-[240px] md:-ml-[210px] md:-mt-[120px] w-[250px] h-[145px] -ml-[125px] -mt-[72px]' },
  { className: 'w-[580px] h-[320px] -ml-[290px] -mt-[160px] animate-orbit-3', size: 'md:w-[580px] md:h-[320px] md:-ml-[290px] md:-mt-[160px] w-[350px] h-[195px] -ml-[175px] -mt-[97px]' },
  { className: 'w-[360px] h-[200px] -ml-[180px] -mt-[100px] animate-orbit-4', size: 'md:w-[360px] md:h-[200px] md:-ml-[180px] md:-mt-[100px] w-[220px] h-[120px] -ml-[110px] -mt-[60px]' },
  { className: 'w-[640px] h-[360px] -ml-[320px] -mt-[180px] animate-orbit-5', size: 'md:w-[640px] md:h-[360px] md:-ml-[320px] md:-mt-[180px] w-[385px] h-[220px] -ml-[192px] -mt-[110px]' },
  { className: 'w-[460px] h-[260px] -ml-[230px] -mt-[130px] animate-orbit-6', size: 'md:w-[460px] md:h-[260px] md:-ml-[230px] md:-mt-[130px] w-[275px] h-[155px] -ml-[137px] -mt-[77px]' },
];

export default function OrbitalCTA() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.2 }
    );

    observer.observe(section);
    return () => observer.disconnect();
  }, []);

  return (
    <section ref={sectionRef} className="relative z-10 bg-forest py-[160px] px-6 overflow-hidden">
      <div className="relative max-w-[700px] mx-auto min-h-[400px] flex items-center justify-center">
        {/* Orbital rings */}
        {rings.map((ring, i) => (
          <div
            key={i}
            className={`absolute top-1/2 left-1/2 ${ring.size} ${isVisible ? ring.className.split(' ').pop() : ''}`}
            style={{
              animationPlayState: isVisible ? 'running' : 'paused',
            }}
          >
            <div
              className="absolute top-0 left-1/2 -translate-x-1/2 rounded-full"
              style={{
                width: i < 3 ? 12 : 10,
                height: i < 3 ? 12 : 10,
                background: 'rgba(201, 168, 76, 0.6)',
                boxShadow: '0 0 12px rgba(201, 168, 76, 0.3)',
              }}
            />
          </div>
        ))}

        {/* Content */}
        <div className="relative z-10 text-center">
          <h2
            className="font-display text-cream-bold"
            style={{
              fontSize: 'clamp(2rem, 4vw, 3rem)',
              textShadow: '0 2px 30px rgba(0,0,0,0.5)',
            }}
          >
            Ready to Close Your Next Deal?
          </h2>
          <p className="font-body text-[18px] text-sage max-w-[480px] mx-auto mt-5 leading-relaxed">
            Join 50,000+ buyers and sellers closing deals every day. Set up your free account in under 60 seconds.
          </p>
          <div className="flex items-center justify-center gap-4 mt-10 flex-wrap">
            <span className="font-body font-semibold text-cream-bold bg-emerald px-9 py-3.5 rounded-[6px] text-[15px] tracking-[0.02em] hover:bg-emerald-light hover:shadow-btn-glow transition-all duration-300 cursor-default">
              Create Free Account
            </span>
            <span className="font-body font-semibold text-cream-bold border border-cream/40 px-9 py-3.5 rounded-[6px] text-[15px] tracking-[0.02em] hover:border-cream hover:bg-cream/[0.08] transition-all duration-300 cursor-default">
              Learn More
            </span>
          </div>

          {/* Tapered wire */}
          <svg
            viewBox="0 0 700 20"
            preserveAspectRatio="none"
            className="w-full max-w-[700px] h-5 mt-[60px] block"
          >
            <defs>
              <linearGradient id="wireGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#C9A84C" stopOpacity="0" />
                <stop offset="20%" stopColor="#C9A84C" stopOpacity="0.8" />
                <stop offset="50%" stopColor="#2D5A3D" stopOpacity="1" />
                <stop offset="80%" stopColor="#C9A84C" stopOpacity="0.8" />
                <stop offset="100%" stopColor="#C9A84C" stopOpacity="0" />
              </linearGradient>
            </defs>
            <line
              x1="0"
              y1="10"
              x2="700"
              y2="10"
              stroke="url(#wireGradient)"
              strokeWidth="1.5"
            />
          </svg>
        </div>
      </div>
    </section>
  );
}
