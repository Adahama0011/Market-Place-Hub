import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const categories = ['Electronics', 'Vehicles', 'Real Estate', 'Services'];
const nodePositions = [
  { cx: 180, cy: 80 },
  { cx: 540, cy: 100 },
  { cx: 900, cy: 100 },
  { cx: 1260, cy: 80 },
];
const nodeColors = ['#C9A84C', '#3D6B4D', '#C9A84C', '#2D5A3D'];

export default function CategoryLine() {
  const containerRef = useRef<HTMLDivElement>(null);
  const pathRef = useRef<SVGPathElement>(null);

  useEffect(() => {
    const path = pathRef.current;
    const container = containerRef.current;
    if (!path || !container) return;

    const length = path.getTotalLength();
    gsap.set(path, {
      strokeDasharray: length,
      strokeDashoffset: length,
    });

    const trigger = ScrollTrigger.create({
      trigger: container,
      start: 'top 80%',
      end: 'top 40%',
      scrub: true,
      onUpdate: (self) => {
        gsap.set(path, {
          strokeDashoffset: length * (1 - self.progress),
        });
      },
    });

    return () => trigger.kill();
  }, []);

  return (
    <div ref={containerRef} className="relative w-full h-[200px] overflow-hidden bg-forest">
      <svg
        viewBox="0 0 1440 200"
        preserveAspectRatio="none"
        className="w-full h-full"
      >
        <defs>
          <linearGradient id="lineGradient" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#C9A84C" />
            <stop offset="50%" stopColor="#2D5A3D" />
            <stop offset="100%" stopColor="#C9A84C" />
          </linearGradient>
        </defs>
        <path
          ref={pathRef}
          d="M0,100 C180,60 360,140 540,100 C720,60 900,140 1080,100 C1260,60 1440,100 1440,100"
          stroke="url(#lineGradient)"
          strokeWidth="1.5"
          fill="none"
          strokeLinecap="round"
        />
        {nodePositions.map((pos, i) => (
          <circle
            key={i}
            cx={pos.cx}
            cy={pos.cy}
            r="6"
            fill={nodeColors[i]}
            className="animate-node-pulse"
            style={{
              animationDelay: `${i * 0.5}s`,
              transformOrigin: `${pos.cx}px ${pos.cy}px`,
            }}
          />
        ))}
      </svg>
      {categories.map((cat, i) => (
        <span
          key={cat}
          className="absolute bottom-10 font-body text-[11px] uppercase tracking-[0.08em] text-sage"
          style={{
            left: `${((nodePositions[i].cx / 1440) * 100).toFixed(1)}%`,
            transform: 'translateX(-50%)',
          }}
        >
          {cat}
        </span>
      ))}
    </div>
  );
}
