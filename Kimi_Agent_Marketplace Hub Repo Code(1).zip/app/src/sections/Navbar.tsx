import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useState, useRef, useEffect } from 'react';
import { LogOut, LayoutDashboard, ClipboardList, ShoppingBag, ChevronDown, Menu, X } from 'lucide-react';

export default function Navbar() {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, isLoggedIn, logout } = useAuth();
  const isHome = location.pathname === '/';
  const [showDropdown, setShowDropdown] = useState(false);
  const [showMobileMenu, setShowMobileMenu] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const scrollToSection = (id: string) => {
    if (!isHome) {
      navigate('/#' + id);
      return;
    }
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
    setShowMobileMenu(false);
  };

  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setShowDropdown(false);
      }
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  // Close mobile menu on route change
  useEffect(() => {
    setShowMobileMenu(false);
    setShowDropdown(false);
  }, [location.pathname]);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 glass-nav h-16">
      <div className="max-w-[1280px] mx-auto h-full flex items-center justify-between px-6">
        <Link to="/" className="font-display text-[22px] text-cream-bold tracking-tight">TradeLink</Link>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-7">
          <button onClick={() => scrollToSection('categories')}
            className="font-body text-[13px] uppercase tracking-[0.08em] text-sage hover:text-cream transition-colors duration-300">
            Categories
          </button>
          <button onClick={() => scrollToSection('how-it-works')}
            className="font-body text-[13px] uppercase tracking-[0.08em] text-sage hover:text-cream transition-colors duration-300">
            How It Works
          </button>
          <button onClick={() => scrollToSection('featured')}
            className="font-body text-[13px] uppercase tracking-[0.08em] text-sage hover:text-cream transition-colors duration-300">
            Deals
          </button>

          {isLoggedIn ? (
            <div className="relative" ref={dropdownRef}>
              <button
                onClick={() => setShowDropdown(!showDropdown)}
                className="flex items-center gap-2 hover:opacity-80 transition-opacity"
              >
                <div className="w-8 h-8 rounded-full bg-emerald/30 overflow-hidden border border-cream/20">
                  <img src={user?.avatar} alt={user?.name} className="w-full h-full object-cover" />
                </div>
                <span className="font-body text-[13px] text-cream hidden lg:block">{user?.name?.split(' ')[0]}</span>
                <ChevronDown size={14} className="text-sage" />
              </button>

              {showDropdown && (
                <div className="absolute right-0 top-full mt-2 w-56 glass-panel rounded-xl py-2 shadow-glass">
                  <div className="px-4 py-2 border-b border-cream/[0.06]">
                    <p className="font-body text-[13px] font-semibold text-cream">{user?.name}</p>
                    <p className="font-body text-[11px] text-sage">{user?.email}</p>
                  </div>
                  <Link to="/dashboard"
                    className="flex items-center gap-2.5 px-4 py-2.5 font-body text-[13px] text-cream hover:bg-cream/5 transition-colors">
                    <LayoutDashboard size={15} /> Dashboard
                  </Link>
                  <Link to="/orders"
                    className="flex items-center gap-2.5 px-4 py-2.5 font-body text-[13px] text-cream hover:bg-cream/5 transition-colors">
                    <ClipboardList size={15} /> Order History
                  </Link>
                  <Link to="/"
                    className="flex items-center gap-2.5 px-4 py-2.5 font-body text-[13px] text-cream hover:bg-cream/5 transition-colors">
                    <ShoppingBag size={15} /> Browse Deals
                  </Link>
                  <div className="border-t border-cream/[0.06] mt-1 pt-1">
                    <button onClick={() => { logout(); navigate('/'); }}
                      className="flex items-center gap-2.5 px-4 py-2.5 font-body text-[13px] text-red-400 hover:bg-red-400/5 transition-colors w-full">
                      <LogOut size={15} /> Sign Out
                    </button>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="flex items-center gap-4">
              <Link to="/login"
                className="font-body text-[13px] uppercase tracking-[0.08em] text-sage hover:text-cream transition-colors duration-300">
                Sign In
              </Link>
              <Link to="/login"
                className="font-body text-[13px] font-medium text-cream-bold bg-emerald px-5 py-2 rounded-full hover:bg-emerald-light transition-colors duration-300">
                Get Started
              </Link>
            </div>
          )}
        </div>

        {/* Mobile Menu Button */}
        <button
          onClick={() => setShowMobileMenu(!showMobileMenu)}
          className="md:hidden text-cream p-1"
        >
          {showMobileMenu ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Menu */}
      {showMobileMenu && (
        <div className="md:hidden glass-nav border-t border-cream/[0.06] px-6 py-4 space-y-3">
          <button onClick={() => scrollToSection('categories')}
            className="block w-full text-left font-body text-[14px] text-cream py-2">Categories</button>
          <button onClick={() => scrollToSection('how-it-works')}
            className="block w-full text-left font-body text-[14px] text-cream py-2">How It Works</button>
          <button onClick={() => scrollToSection('featured')}
            className="block w-full text-left font-body text-[14px] text-cream py-2">Deals</button>

          {isLoggedIn ? (
            <>
              <div className="border-t border-cream/[0.06] pt-3 flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-emerald/30 overflow-hidden">
                  <img src={user?.avatar} alt={user?.name} className="w-full h-full object-cover" />
                </div>
                <div>
                  <p className="font-body text-[14px] font-semibold text-cream">{user?.name}</p>
                  <p className="font-body text-[12px] text-sage">{user?.email}</p>
                </div>
              </div>
              <Link to="/dashboard" className="block font-body text-[14px] text-cream py-2 flex items-center gap-2">
                <LayoutDashboard size={15} /> Dashboard
              </Link>
              <Link to="/orders" className="block font-body text-[14px] text-cream py-2 flex items-center gap-2">
                <ClipboardList size={15} /> Order History
              </Link>
              <button onClick={() => { logout(); navigate('/'); }}
                className="block w-full text-left font-body text-[14px] text-red-400 py-2 flex items-center gap-2">
                <LogOut size={15} /> Sign Out
              </button>
            </>
          ) : (
            <div className="border-t border-cream/[0.06] pt-3 flex gap-3">
              <Link to="/login" className="flex-1 text-center font-body text-[14px] text-cream border border-cream/40 py-2.5 rounded-lg">
                Sign In
              </Link>
              <Link to="/login" className="flex-1 text-center font-body text-[14px] font-medium text-cream-bold bg-emerald py-2.5 rounded-lg">
                Get Started
              </Link>
            </div>
          )}
        </div>
      )}
    </nav>
  );
}
