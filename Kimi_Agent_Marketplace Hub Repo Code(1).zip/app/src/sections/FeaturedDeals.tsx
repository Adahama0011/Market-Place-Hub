import { useStaggerFadeIn } from '../hooks/useScrollAnimation';
import { deals } from '../data/deals';
import DealCard from './DealCard';

export default function FeaturedDeals() {
  const gridRef = useStaggerFadeIn(0.08);

  return (
    <section id="featured" className="relative z-10 bg-forest py-[120px] px-6">
      <div className="max-w-[1280px] mx-auto">
        <div className="flex items-center justify-between">
          <h2
            className="font-display text-cream"
            style={{ fontSize: 'clamp(1.5rem, 3vw, 2.5rem)' }}
          >
            Featured Deals
          </h2>
          <span className="font-body text-[14px] uppercase tracking-[0.08em] text-gold hover:underline cursor-default">
            View All &rarr;
          </span>
        </div>

        <div
          ref={gridRef}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mt-12"
        >
          {deals.map((deal) => (
            <DealCard key={deal.id} deal={deal} />
          ))}
        </div>
      </div>
    </section>
  );
}
