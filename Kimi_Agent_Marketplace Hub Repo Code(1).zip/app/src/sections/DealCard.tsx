import { Link } from 'react-router-dom';
import { Star } from 'lucide-react';
import type { Deal } from '../data/deals';

interface DealCardProps {
  deal: Deal;
  compact?: boolean;
}

export default function DealCard({ deal, compact = false }: DealCardProps) {
  const discount = Math.round(((deal.originalPrice - deal.price) / deal.originalPrice) * 100);

  if (compact) {
    return (
      <Link
        to={`/deal/${deal.id}`}
        className="block bg-forest-dark rounded-xl overflow-hidden border border-cream/[0.06] group hover:-translate-y-1 hover:shadow-card-hover hover:border-gold/20 transition-all duration-300 easing-smooth"
      >
        <div className="aspect-[16/10] overflow-hidden">
          <img
            src={deal.image}
            alt={deal.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
        </div>
        <div className="p-4">
          <span className="inline-block font-body text-[11px] text-emerald bg-emerald/20 px-2.5 py-1 rounded mb-2">
            {deal.category}
          </span>
          <h3 className="font-body text-[14px] font-semibold text-cream line-clamp-1">
            {deal.title}
          </h3>
          <div className="flex items-center gap-2 mt-2">
            <span className="font-mono text-[18px] font-bold text-gold">
              ${deal.price.toLocaleString()}
            </span>
            <span className="font-mono text-[12px] text-sage line-through">
              ${deal.originalPrice.toLocaleString()}
            </span>
          </div>
        </div>
      </Link>
    );
  }

  return (
    <Link
      to={`/deal/${deal.id}`}
      className="block bg-forest-dark rounded-xl overflow-hidden border border-cream/[0.06] group hover:-translate-y-1 hover:shadow-card-hover hover:border-gold/20 transition-all duration-300 easing-smooth"
    >
      <div className="relative aspect-[4/3] overflow-hidden">
        <img
          src={deal.image}
          alt={deal.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        {discount > 0 && (
          <span className="absolute top-3 left-3 bg-emerald text-cream-bold font-mono text-[11px] font-bold px-2 py-1 rounded">
            -{discount}%
          </span>
        )}
      </div>
      <div className="p-5 pb-6">
        <h3 className="font-body text-[16px] font-semibold text-cream line-clamp-1">
          {deal.title}
        </h3>
        <span className="inline-block font-body text-[12px] text-emerald bg-emerald/20 px-2.5 py-1 rounded mt-2">
          {deal.category}
        </span>
        <div className="flex items-center gap-3 mt-3">
          <span className="font-mono text-[22px] font-bold text-gold">
            ${deal.price.toLocaleString()}
          </span>
          <span className="font-mono text-[14px] text-sage line-through">
            ${deal.originalPrice.toLocaleString()}
          </span>
        </div>
        <div className="flex items-center gap-3 mt-4 pt-4 border-t border-cream/[0.06]">
          <div className="w-7 h-7 rounded-full bg-emerald/30 overflow-hidden flex-shrink-0">
            <img src={deal.seller.avatar} alt={deal.seller.name} className="w-full h-full object-cover" />
          </div>
          <span className="font-body text-[13px] text-sage truncate">{deal.seller.name}</span>
          <div className="flex items-center gap-1 ml-auto flex-shrink-0">
            <Star size={12} className="text-gold fill-gold" />
            <span className="font-body text-[13px] text-gold">{deal.seller.rating}</span>
          </div>
        </div>
      </div>
    </Link>
  );
}
