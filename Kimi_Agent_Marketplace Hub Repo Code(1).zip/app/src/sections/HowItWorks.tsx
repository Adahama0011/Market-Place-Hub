import { useStepsStagger } from '../hooks/useScrollAnimation';

const steps = [
  {
    num: '01',
    title: 'Browse & Discover',
    desc: 'Search thousands of verified listings. Filter by category, price, location, and seller rating.',
  },
  {
    num: '02',
    title: 'Connect & Negotiate',
    desc: 'Message sellers directly. Ask questions, request custom quotes, and negotiate terms in real-time.',
  },
  {
    num: '03',
    title: 'Lock & Transact',
    desc: 'Secure your deal with escrow protection. Funds release only when both parties confirm satisfaction.',
  },
];

export default function HowItWorks() {
  const stepsRef = useStepsStagger();

  return (
    <section id="how-it-works" className="relative z-10 bg-forest py-[120px] px-6">
      <div className="max-w-[1000px] mx-auto">
        <h2
          className="font-display text-cream text-center"
          style={{ fontSize: 'clamp(1.5rem, 3vw, 2.5rem)' }}
        >
          Close Deals in 3 Steps
        </h2>
        <div className="w-[60px] h-[2px] bg-gold mx-auto mt-4 mb-16" />

        {/* Connecting line - horizontal on desktop, vertical on mobile */}
        <div className="relative">
          <div
            className="hidden md:block absolute top-[36px] left-[16.67%] right-[16.67%] h-[1px]"
            style={{
              background: 'linear-gradient(to right, transparent, #C9A84C, transparent)',
            }}
          />
          <div
            className="md:hidden absolute top-0 bottom-0 left-[27px] w-[1px]"
            style={{
              background: 'linear-gradient(to bottom, transparent, #C9A84C, transparent)',
            }}
          />

          <div ref={stepsRef} className="grid grid-cols-1 md:grid-cols-3 gap-12 md:gap-12">
            {steps.map((step) => (
              <div key={step.num} className="relative pl-[72px] md:pl-0 md:text-center">
                <span
                  className="absolute left-0 md:left-1/2 md:-translate-x-1/2 top-0 font-display text-[72px] leading-none text-gold/20 select-none"
                >
                  {step.num}
                </span>
                <div className="md:mt-[100px]">
                  <h3 className="font-body text-[20px] font-semibold text-cream">
                    {step.title}
                  </h3>
                  <p className="font-body text-[16px] text-sage mt-3 leading-relaxed">
                    {step.desc}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
