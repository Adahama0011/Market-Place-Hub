import { useParams, Link } from 'react-router-dom';
import { Star, Heart, ChevronRight, MessageCircle, Send } from 'lucide-react';
import { deals } from '../data/deals';
import DealCard from '../sections/DealCard';
import CategoryLine from '../sections/CategoryLine';
import Footer from '../sections/Footer';

export default function DealDetailPage() {
  const { id } = useParams<{ id: string }>();
  const deal = deals.find((d) => d.id === id);

  if (!deal) {
    return (
      <div className="min-h-screen bg-forest flex items-center justify-center">
        <div className="text-center">
          <h1 className="font-display text-cream text-3xl">Deal not found</h1>
          <Link to="/" className="font-body text-gold mt-4 inline-block hover:underline">
            &larr; Back to home
          </Link>
        </div>
      </div>
    );
  }

  const relatedDeals = deals.filter((d) => d.id !== deal.id && d.category === deal.category).slice(0, 4);
  const discount = Math.round(((deal.originalPrice - deal.price) / deal.originalPrice) * 100);

  return (
    <main className="relative z-10 bg-forest">
      {/* Deal Header */}
      <section className="pt-[100px] pb-[60px] px-6">
        <div className="max-w-[1280px] mx-auto">
          {/* Breadcrumb */}
          <div className="flex items-center gap-2 mb-6 font-body text-[13px] text-sage">
            <Link to="/" className="hover:text-cream transition-colors">Home</Link>
            <ChevronRight size={14} />
            <span>{deal.category}</span>
            {deal.subcategory && (
              <>
                <ChevronRight size={14} />
                <span>{deal.subcategory}</span>
              </>
            )}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-5 gap-10">
            {/* Left - Image Gallery */}
            <div className="lg:col-span-3">
              <div className="aspect-[4/3] rounded-xl overflow-hidden border border-cream/[0.06]">
                <img
                  src={deal.image}
                  alt={deal.title}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="flex gap-2 mt-3">
                {[deal.image, deal.image, deal.image, deal.image].map((img, i) => (
                  <div
                    key={i}
                    className="w-16 h-16 rounded-md overflow-hidden border border-cream/[0.06] opacity-70 hover:opacity-100 cursor-pointer transition-opacity"
                  >
                    <img src={img} alt="" className="w-full h-full object-cover" />
                  </div>
                ))}
              </div>
            </div>

            {/* Right - Deal Info */}
            <div className="lg:col-span-2">
              <h1 className="font-display text-cream text-[28px] leading-tight">
                {deal.title}
              </h1>

              <div className="flex items-center gap-3 mt-4">
                <span className="font-mono text-[36px] font-bold text-gold">
                  ${deal.price.toLocaleString()}
                </span>
                <span className="font-mono text-[16px] text-sage line-through">
                  ${deal.originalPrice.toLocaleString()}
                </span>
                {discount > 0 && (
                  <span className="font-mono text-[12px] font-bold text-emerald bg-emerald/20 px-2 py-1 rounded">
                    SAVE {discount}%
                  </span>
                )}
              </div>

              {/* Seller Card */}
              <div className="flex items-center gap-3 mt-6 p-4 bg-forest-dark/50 rounded-lg border border-cream/[0.06]">
                <div className="w-10 h-10 rounded-full bg-emerald/30 overflow-hidden flex-shrink-0">
                  <img src={deal.seller.avatar} alt={deal.seller.name} className="w-full h-full object-cover" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-body text-[15px] font-semibold text-cream">{deal.seller.name}</span>
                    {deal.seller.verified && (
                      <span className="font-body text-[11px] uppercase text-emerald bg-emerald/20 px-2 py-0.5 rounded">
                        Verified Seller
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-1 mt-0.5">
                    <Star size={12} className="text-gold fill-gold" />
                    <span className="font-body text-[13px] text-gold">{deal.seller.rating}</span>
                    <span className="font-body text-[13px] text-sage">({deal.seller.reviews} reviews)</span>
                  </div>
                </div>
              </div>

              {/* Key Details */}
              {(deal.condition || deal.location || deal.listedAgo || deal.views) && (
                <div className="grid grid-cols-2 gap-3 mt-6">
                  {deal.condition && (
                    <div className="bg-forest-dark/50 p-3 rounded-md">
                      <span className="font-body text-[12px] text-sage uppercase block">Condition</span>
                      <span className="font-body text-[14px] text-cream font-medium">{deal.condition}</span>
                    </div>
                  )}
                  {deal.location && (
                    <div className="bg-forest-dark/50 p-3 rounded-md">
                      <span className="font-body text-[12px] text-sage uppercase block">Location</span>
                      <span className="font-body text-[14px] text-cream font-medium">{deal.location}</span>
                    </div>
                  )}
                  {deal.listedAgo && (
                    <div className="bg-forest-dark/50 p-3 rounded-md">
                      <span className="font-body text-[12px] text-sage uppercase block">Listed</span>
                      <span className="font-body text-[14px] text-cream font-medium">{deal.listedAgo}</span>
                    </div>
                  )}
                  {deal.views && (
                    <div className="bg-forest-dark/50 p-3 rounded-md">
                      <span className="font-body text-[12px] text-sage uppercase block">Views</span>
                      <span className="font-body text-[14px] text-cream font-medium">{deal.views.toLocaleString()}</span>
                    </div>
                  )}
                </div>
              )}

              {/* CTA Buttons */}
              <div className="flex flex-col gap-3 mt-8">
                <Link
                  to={`/checkout/${deal.id}`}
                  className="w-full font-body font-semibold text-cream-bold bg-emerald py-4 rounded-lg text-[16px] hover:bg-emerald-light hover:shadow-btn-glow transition-all duration-300 flex items-center justify-center gap-2"
                >
                  <Send size={18} />
                  Make an Offer
                </Link>
                <button className="w-full font-body font-semibold text-cream-bold border border-cream/40 py-4 rounded-lg text-[16px] hover:border-cream hover:bg-cream/[0.08] transition-all duration-300 flex items-center justify-center gap-2">
                  <MessageCircle size={18} />
                  Message Seller
                </button>
                <button className="w-12 h-12 border border-cream/40 rounded-lg flex items-center justify-center text-cream hover:border-cream hover:bg-cream/[0.08] transition-all duration-300 flex-shrink-0">
                  <Heart size={18} />
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Description */}
      {deal.description && (
        <section className="py-[60px] px-6">
          <div className="max-w-[800px]">
            <h2 className="font-display text-cream text-[22px] mb-6">Description</h2>
            <div className="font-body text-[16px] text-sage leading-[1.7] space-y-4">
              <p>{deal.description}</p>
            </div>

            {/* Specs */}
            {deal.specs && deal.specs.length > 0 && (
              <div className="mt-8">
                <div className="border-t border-cream/[0.08]">
                  {deal.specs.map((spec) => (
                    <div
                      key={spec.label}
                      className="flex justify-between py-3 border-b border-cream/[0.06]"
                    >
                      <span className="font-body text-[14px] text-sage">{spec.label}</span>
                      <span className="font-body text-[14px] text-cream font-medium">{spec.value}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </section>
      )}

      {/* Category Gradient Divider */}
      <CategoryLine />

      {/* Related Deals */}
      {relatedDeals.length > 0 && (
        <section className="py-[80px] pb-[120px] px-6">
          <div className="max-w-[1280px] mx-auto">
            <h2
              className="font-display text-cream mb-10"
              style={{ fontSize: 'clamp(1.5rem, 3vw, 2.5rem)' }}
            >
              More Deals You'll Love
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {relatedDeals.map((d) => (
                <DealCard key={d.id} deal={d} compact />
              ))}
            </div>
          </div>
        </section>
      )}

      <Footer />
    </main>
  );
}
