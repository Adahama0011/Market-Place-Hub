import HeroSection from '../sections/HeroSection';
import TrustedByBar from '../sections/TrustedByBar';
import TrendingCategories from '../sections/TrendingCategories';
import HowItWorks from '../sections/HowItWorks';
import FeaturedDeals from '../sections/FeaturedDeals';
import OrbitalCTA from '../sections/OrbitalCTA';
import Footer from '../sections/Footer';

export default function HomePage() {
  return (
    <main className="relative">
      {/* Hero + video background sections */}
      <HeroSection />
      <TrustedByBar />
      <TrendingCategories />

      {/* Dark flat lower page */}
      <div className="relative z-10 bg-forest">
        <HowItWorks />
        <FeaturedDeals />
        <OrbitalCTA />
        <Footer />
      </div>
    </main>
  );
}
