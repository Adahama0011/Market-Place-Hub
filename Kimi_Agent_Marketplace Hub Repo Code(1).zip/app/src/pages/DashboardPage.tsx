import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { getOrdersForUser } from '../data/orders';
import { STATUS_LABELS, STATUS_COLORS } from '../data/orders';
import type { Order } from '../data/orders';
import Footer from '../sections/Footer';
import {
  ShoppingBag, Package, CheckCircle, TrendingDown, Eye,
  BarChart3, Wallet, ChevronRight, MapPin, Calendar
} from 'lucide-react';
import { useMemo } from 'react';

export default function DashboardPage() {
  const { user } = useAuth();
  const orders = useMemo(() => {
    if (!user) return [];
    return getOrdersForUser(user.id, user.email);
  }, [user]);

  const activeOrders = orders.filter((o) =>
    !['completed', 'cancelled', 'disputed'].includes(o.status)
  );
  const completedOrders = orders.filter((o) => o.status === 'completed');
  const totalSpent = completedOrders.reduce((sum, o) => sum + o.total, 0);
  const totalSaved = completedOrders.reduce((sum, o) => sum + Math.max(0, o.savings * o.quantity), 0);

  const stats = [
    { label: 'Active Orders', value: activeOrders.length, icon: <Package size={20} />, color: '#C9A84C' },
    { label: 'Completed', value: completedOrders.length, icon: <CheckCircle size={20} />, color: '#2D5A3D' },
    { label: 'Total Spent', value: `$${totalSpent.toLocaleString()}`, icon: <Wallet size={20} />, color: '#D4A843' },
    { label: 'Saved', value: `$${totalSaved.toLocaleString()}`, icon: <TrendingDown size={20} />, color: '#8B9E7A' },
  ];

  return (
    <main className="relative z-10 bg-forest min-h-screen">
      {/* Header */}
      <section className="pt-[100px] pb-[40px] px-6">
        <div className="max-w-[1280px] mx-auto">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-full bg-emerald/30 overflow-hidden border-2 border-gold/30">
              <img src={user?.avatar} alt={user?.name} className="w-full h-full object-cover" />
            </div>
            <div>
              <h1 className="font-display text-cream-bold text-[28px]">{user?.name}</h1>
              <p className="font-body text-[13px] text-sage">{user?.email} · {user?.role === 'buyer' ? 'Buyer' : 'Seller'} Account</p>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Cards */}
      <section className="px-6 pb-[40px]">
        <div className="max-w-[1280px] mx-auto grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {stats.map((stat) => (
            <div key={stat.label} className="glass-panel rounded-xl p-5">
              <div className="flex items-center justify-between">
                <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ background: `${stat.color}20` }}>
                  <span style={{ color: stat.color }}>{stat.icon}</span>
                </div>
                <span className="font-mono text-[22px] font-bold text-cream">{stat.value}</span>
              </div>
              <p className="font-body text-[12px] uppercase tracking-[0.08em] text-sage mt-3">{stat.label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Active Orders */}
      <section className="px-6 pb-[40px]">
        <div className="max-w-[1280px] mx-auto">
          <div className="flex items-center justify-between mb-6">
            <h2 className="font-display text-cream text-[22px]">Active Orders</h2>
            <Link to="/orders" className="font-body text-[13px] uppercase tracking-[0.08em] text-gold hover:underline flex items-center gap-1">
              View All <ChevronRight size={14} />
            </Link>
          </div>

          {activeOrders.length === 0 ? (
            <div className="glass-panel rounded-xl p-10 text-center">
              <Package size={40} className="text-sage/30 mx-auto mb-4" />
              <h3 className="font-body text-[16px] font-semibold text-cream">No Active Orders</h3>
              <p className="font-body text-[14px] text-sage mt-2">Browse deals and make your first purchase!</p>
              <Link to="/" className="inline-block mt-4 font-body font-semibold text-cream-bold bg-emerald px-6 py-2.5 rounded-lg text-[14px] hover:bg-emerald-light transition-all">
                Browse Deals
              </Link>
            </div>
          ) : (
            <div className="space-y-4">
              {activeOrders.slice(0, 3).map((order) => (
                <OrderRow key={order.id} order={order} />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Recent Activity */}
      <section className="px-6 pb-[120px]">
        <div className="max-w-[1280px] mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Quick Actions */}
            <div className="glass-panel rounded-xl p-6">
              <h3 className="font-body text-[14px] uppercase tracking-[0.08em] text-sage mb-4">Quick Actions</h3>
              <div className="space-y-3">
                <Link to="/" className="flex items-center gap-3 p-3 rounded-lg bg-forest-dark/40 hover:bg-forest-dark/60 border border-cream/[0.06] hover:border-gold/30 transition-all group">
                  <ShoppingBag size={18} className="text-gold" />
                  <span className="font-body text-[14px] text-cream group-hover:text-cream-bold transition-colors">Browse Deals</span>
                </Link>
                <Link to="/orders" className="flex items-center gap-3 p-3 rounded-lg bg-forest-dark/40 hover:bg-forest-dark/60 border border-cream/[0.06] hover:border-gold/30 transition-all group">
                  <BarChart3 size={18} className="text-gold" />
                  <span className="font-body text-[14px] text-cream group-hover:text-cream-bold transition-colors">Order History</span>
                </Link>
              </div>
            </div>

            {/* Recent Completed */}
            <div className="lg:col-span-2 glass-panel rounded-xl p-6">
              <h3 className="font-body text-[14px] uppercase tracking-[0.08em] text-sage mb-4">Recently Completed</h3>
              {completedOrders.length === 0 ? (
                <p className="font-body text-[14px] text-sage py-6 text-center">No completed orders yet.</p>
              ) : (
                <div className="space-y-3">
                  {completedOrders.slice(0, 4).map((order) => (
                    <div key={order.id} className="flex items-center gap-4 p-3 rounded-lg bg-forest-dark/30">
                      <div className="w-12 h-12 rounded-lg overflow-hidden flex-shrink-0">
                        <img src={order.deal.image} alt="" className="w-full h-full object-cover" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-body text-[14px] text-cream truncate">{order.deal.title}</p>
                        <p className="font-mono text-[12px] text-sage">{order.id}</p>
                      </div>
                      <span className="font-mono text-[14px] font-bold text-emerald flex-shrink-0">${order.total.toLocaleString()}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  );
}

function OrderRow({ order }: { order: Order }) {
  const progress = getOrderProgress(order);

  return (
    <div className="glass-panel rounded-xl p-5 hover:border-gold/20 transition-all">
      <div className="flex flex-col sm:flex-row sm:items-center gap-4">
        <div className="w-16 h-16 rounded-lg overflow-hidden flex-shrink-0">
          <img src={order.deal.image} alt="" className="w-full h-full object-cover" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-3 flex-wrap">
            <span className="font-mono text-[12px] text-sage">{order.id}</span>
            <span
              className="font-body text-[11px] uppercase tracking-[0.06em] px-2 py-0.5 rounded font-medium"
              style={{ background: `${STATUS_COLORS[order.status]}20`, color: STATUS_COLORS[order.status] }}
            >
              {STATUS_LABELS[order.status]}
            </span>
          </div>
          <h3 className="font-body text-[15px] font-semibold text-cream mt-1 truncate">{order.deal.title}</h3>
          <div className="flex items-center gap-4 mt-1">
            <span className="font-body text-[12px] text-sage flex items-center gap-1">
              <MapPin size={12} /> {order.deal.location}
            </span>
            <span className="font-body text-[12px] text-sage flex items-center gap-1">
              <Calendar size={12} /> {new Date(order.createdAt).toLocaleDateString()}
            </span>
          </div>
        </div>
        <div className="flex items-center gap-4 flex-shrink-0">
          <span className="font-mono text-[18px] font-bold text-gold">${order.total.toLocaleString()}</span>
          <Link
            to={`/order/${order.id}`}
            className="font-body text-[13px] font-medium text-cream bg-emerald/80 hover:bg-emerald px-4 py-2 rounded-lg transition-all flex items-center gap-1"
          >
            <Eye size={14} /> Track
          </Link>
        </div>
      </div>
      {/* Progress bar */}
      <div className="mt-4">
        <div className="w-full h-1.5 bg-forest-dark/60 rounded-full overflow-hidden">
          <div
            className="h-full rounded-full transition-all duration-700"
            style={{ width: `${progress}%`, background: `linear-gradient(to right, ${STATUS_COLORS.pending}, ${STATUS_COLORS.confirmed}, ${STATUS_COLORS.delivered})` }}
          />
        </div>
        <div className="flex justify-between mt-2">
          {['Pending', 'Processing', 'Shipped', 'Delivered', 'Completed'].map((s, i) => (
            <span key={s} className="font-body text-[10px] uppercase tracking-[0.06em]" style={{ color: i * 25 <= progress ? '#C9A84C' : '#8B9E7A' }}>
              {s}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}

function getOrderProgress(order: Order): number {
  const flow = ['pending', 'processing', 'confirmed', 'shipped', 'in_transit', 'delivered', 'completed'];
  const idx = flow.indexOf(order.status);
  if (idx === -1) return 0;
  return Math.round((idx / (flow.length - 1)) * 100);
}
