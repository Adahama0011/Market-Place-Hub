import { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { deals } from '../data/deals';
import { createOrder } from '../data/orders';
import { Shield, MapPin, FileText, ChevronRight, Lock, Truck, CheckCircle } from 'lucide-react';
import Footer from '../sections/Footer';

export default function OrderCreatePage() {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const deal = deals.find((d) => d.id === id);

  const [offerPrice, setOfferPrice] = useState(deal?.price || 0);
  const [quantity, setQuantity] = useState(1);
  const [shippingAddress, setShippingAddress] = useState('');
  const [notes, setNotes] = useState('');
  const [step, setStep] = useState<'offer' | 'review' | 'success'>('offer');
  const [createdOrderId, setCreatedOrderId] = useState('');

  if (!deal) {
    return (
      <div className="min-h-screen bg-forest flex items-center justify-center">
        <div className="text-center">
          <h1 className="font-display text-cream text-3xl">Deal not found</h1>
          <Link to="/" className="font-body text-gold mt-4 inline-block hover:underline">&larr; Back to home</Link>
        </div>
      </div>
    );
  }

  const savings = deal.price - offerPrice;
  const total = offerPrice * quantity;
  const escrowFee = Math.round(total * 0.025);
  const grandTotal = total + escrowFee;

  const handleSubmitOffer = () => {
    if (!user) return;
    setStep('review');
  };

  const handleConfirmOrder = () => {
    if (!user) return;
    const order = createOrder(deal, user.id, user.name, user.email, offerPrice, quantity, shippingAddress, notes);
    setCreatedOrderId(order.id);
    setStep('success');
  };

  return (
    <main className="relative z-10 bg-forest min-h-screen">
      {/* Breadcrumb */}
      <section className="pt-[100px] pb-6 px-6">
        <div className="max-w-[800px] mx-auto">
          <div className="flex items-center gap-2 font-body text-[13px] text-sage">
            <Link to="/" className="hover:text-cream transition-colors">Home</Link>
            <ChevronRight size={14} />
            <Link to={`/deal/${deal.id}`} className="hover:text-cream transition-colors">Deal</Link>
            <ChevronRight size={14} />
            <span className="text-cream">Checkout</span>
          </div>
        </div>
      </section>

      {step === 'offer' && (
        <section className="px-6 pb-[120px]">
          <div className="max-w-[800px] mx-auto">
            <h1 className="font-display text-cream-bold text-[28px] mb-2">Make an Offer</h1>
            <p className="font-body text-sage text-[15px] mb-8">Your offer will be held in escrow until both parties confirm satisfaction.</p>

            {/* Deal Summary */}
            <div className="glass-panel rounded-xl p-5 mb-6 flex gap-4">
              <div className="w-20 h-20 rounded-lg overflow-hidden flex-shrink-0">
                <img src={deal.image} alt="" className="w-full h-full object-cover" />
              </div>
              <div>
                <h3 className="font-body text-[15px] font-semibold text-cream">{deal.title}</h3>
                <p className="font-body text-[13px] text-sage mt-1">Sold by {deal.seller.name}</p>
                <p className="font-mono text-[18px] font-bold text-gold mt-2">${deal.price.toLocaleString()}</p>
              </div>
            </div>

            {/* Offer Form */}
            <div className="glass-panel rounded-xl p-6 space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                  <label className="block font-body text-[12px] uppercase tracking-[0.08em] text-sage mb-2">Your Offer Price</label>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 font-mono text-[14px] text-sage">$</span>
                    <input
                      type="number"
                      value={offerPrice}
                      onChange={(e) => setOfferPrice(Number(e.target.value))}
                      min={1}
                      className="w-full bg-forest-dark/60 border border-cream/[0.08] rounded-lg pl-8 pr-4 py-3 font-mono text-[16px] text-cream focus:outline-none focus:border-gold/50 transition-colors"
                    />
                  </div>
                  {savings > 0 && (
                    <p className="font-body text-[12px] text-emerald mt-1.5">You save ${savings.toLocaleString()} ({Math.round((savings / deal.price) * 100)}% off)</p>
                  )}
                  {savings < 0 && (
                    <p className="font-body text-[12px] text-gold-amber mt-1.5">Your offer is ${Math.abs(savings).toLocaleString()} above listing price</p>
                  )}
                </div>

                <div>
                  <label className="block font-body text-[12px] uppercase tracking-[0.08em] text-sage mb-2">Quantity</label>
                  <input
                    type="number"
                    value={quantity}
                    onChange={(e) => setQuantity(Math.max(1, Number(e.target.value)))}
                    min={1}
                    className="w-full bg-forest-dark/60 border border-cream/[0.08] rounded-lg px-4 py-3 font-mono text-[16px] text-cream focus:outline-none focus:border-gold/50 transition-colors"
                  />
                </div>
              </div>

              <div>
                <label className="block font-body text-[12px] uppercase tracking-[0.08em] text-sage mb-2 flex items-center gap-1.5">
                  <MapPin size={13} /> Shipping Address
                </label>
                <textarea
                  value={shippingAddress}
                  onChange={(e) => setShippingAddress(e.target.value)}
                  placeholder="Enter your full shipping address..."
                  rows={3}
                  className="w-full bg-forest-dark/60 border border-cream/[0.08] rounded-lg px-4 py-3 font-body text-[14px] text-cream placeholder:text-sage/50 focus:outline-none focus:border-gold/50 transition-colors resize-none"
                />
              </div>

              <div>
                <label className="block font-body text-[12px] uppercase tracking-[0.08em] text-sage mb-2 flex items-center gap-1.5">
                  <FileText size={13} /> Notes (Optional)
                </label>
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Any special requests or questions for the seller..."
                  rows={2}
                  className="w-full bg-forest-dark/60 border border-cream/[0.08] rounded-lg px-4 py-3 font-body text-[14px] text-cream placeholder:text-sage/50 focus:outline-none focus:border-gold/50 transition-colors resize-none"
                />
              </div>

              <button
                onClick={handleSubmitOffer}
                className="w-full font-body font-semibold text-cream-bold bg-emerald py-4 rounded-lg text-[16px] hover:bg-emerald-light hover:shadow-btn-glow transition-all duration-300 flex items-center justify-center gap-2"
              >
                <Lock size={18} />
                Submit Offer via Escrow
              </button>

              <div className="flex items-center justify-center gap-2 text-sage/60">
                <Shield size={14} />
                <span className="font-body text-[12px]">Funds held securely until delivery confirmed</span>
              </div>
            </div>
          </div>
        </section>
      )}

      {step === 'review' && (
        <section className="px-6 pb-[120px]">
          <div className="max-w-[600px] mx-auto">
            <h1 className="font-display text-cream-bold text-[28px] mb-2">Review Your Order</h1>
            <p className="font-body text-sage text-[15px] mb-8">Please confirm the details before placing your order.</p>

            <div className="glass-panel rounded-xl p-6 space-y-5">
              <div className="flex gap-4 pb-5 border-b border-cream/[0.06]">
                <div className="w-16 h-16 rounded-lg overflow-hidden flex-shrink-0">
                  <img src={deal.image} alt="" className="w-full h-full object-cover" />
                </div>
                <div>
                  <h3 className="font-body text-[15px] font-semibold text-cream">{deal.title}</h3>
                  <p className="font-body text-[13px] text-sage">{deal.seller.name} · {deal.condition}</p>
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex justify-between font-body text-[14px]">
                  <span className="text-sage">Offer Price</span>
                  <span className="text-cream">${offerPrice.toLocaleString()} x {quantity}</span>
                </div>
                <div className="flex justify-between font-body text-[14px]">
                  <span className="text-sage">Subtotal</span>
                  <span className="text-cream font-medium">${total.toLocaleString()}</span>
                </div>
                <div className="flex justify-between font-body text-[14px]">
                  <span className="text-sage flex items-center gap-1"><Shield size={12} /> Escrow Fee (2.5%)</span>
                  <span className="text-cream">${escrowFee.toLocaleString()}</span>
                </div>
                {savings > 0 && (
                  <div className="flex justify-between font-body text-[14px]">
                    <span className="text-emerald">You Save</span>
                    <span className="text-emerald font-medium">-${(savings * quantity).toLocaleString()}</span>
                  </div>
                )}
                <div className="flex justify-between font-body text-[16px] pt-3 border-t border-cream/[0.08]">
                  <span className="text-cream-bold font-semibold">Total</span>
                  <span className="font-mono text-gold font-bold">${grandTotal.toLocaleString()}</span>
                </div>
              </div>

              {shippingAddress && (
                <div className="pt-3 border-t border-cream/[0.06]">
                  <span className="font-body text-[12px] uppercase tracking-[0.08em] text-sage flex items-center gap-1"><MapPin size={12} /> Shipping To</span>
                  <p className="font-body text-[14px] text-cream mt-1">{shippingAddress}</p>
                </div>
              )}

              {notes && (
                <div className="pt-3 border-t border-cream/[0.06]">
                  <span className="font-body text-[12px] uppercase tracking-[0.08em] text-sage flex items-center gap-1"><FileText size={12} /> Notes</span>
                  <p className="font-body text-[14px] text-cream mt-1">{notes}</p>
                </div>
              )}

              <div className="flex gap-3 pt-3">
                <button
                  onClick={() => setStep('offer')}
                  className="flex-1 font-body font-semibold text-cream border border-cream/40 py-3.5 rounded-lg text-[15px] hover:border-cream hover:bg-cream/[0.08] transition-all"
                >
                  Edit
                </button>
                <button
                  onClick={handleConfirmOrder}
                  className="flex-[2] font-body font-semibold text-cream-bold bg-emerald py-3.5 rounded-lg text-[15px] hover:bg-emerald-light hover:shadow-btn-glow transition-all flex items-center justify-center gap-2"
                >
                  <Lock size={18} />
                  Confirm & Place Order
                </button>
              </div>
            </div>
          </div>
        </section>
      )}

      {step === 'success' && (
        <section className="px-6 pb-[120px]">
          <div className="max-w-[600px] mx-auto text-center">
            <div className="w-20 h-20 rounded-full bg-emerald/20 flex items-center justify-center mx-auto mb-6">
              <CheckCircle size={40} className="text-emerald" />
            </div>
            <h1 className="font-display text-cream-bold text-[28px] mb-2">Order Placed Successfully!</h1>
            <p className="font-body text-sage text-[15px] mb-2">Your offer has been submitted and funds secured in escrow.</p>
            <p className="font-mono text-gold text-[14px] mb-8">{createdOrderId}</p>

            <div className="glass-panel rounded-xl p-6 mb-8 text-left">
              <div className="flex items-center gap-3 mb-4">
                <Shield size={20} className="text-emerald" />
                <div>
                  <h3 className="font-body text-[14px] font-semibold text-cream">Escrow Protection Active</h3>
                  <p className="font-body text-[12px] text-sage">Funds released only when you confirm delivery</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Truck size={20} className="text-gold" />
                <div>
                  <h3 className="font-body text-[14px] font-semibold text-cream">Estimated Delivery</h3>
                  <p className="font-body text-[12px] text-sage">3-5 business days after seller confirms</p>
                </div>
              </div>
            </div>

            <div className="flex gap-3 justify-center">
              <Link
                to={`/order/${createdOrderId}`}
                className="font-body font-semibold text-cream-bold bg-emerald px-8 py-3.5 rounded-lg text-[15px] hover:bg-emerald-light transition-all"
              >
                Track Order
              </Link>
              <Link
                to="/orders"
                className="font-body font-semibold text-cream border border-cream/40 px-8 py-3.5 rounded-lg text-[15px] hover:border-cream hover:bg-cream/[0.08] transition-all"
              >
                Order History
              </Link>
            </div>
          </div>
        </section>
      )}

      <Footer />
    </main>
  );
}
