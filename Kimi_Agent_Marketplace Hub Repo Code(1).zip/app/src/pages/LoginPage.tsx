import { useState } from 'react';
import { useNavigate, useLocation, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { LogIn, UserPlus, Eye, EyeOff } from 'lucide-react';

export default function LoginPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const { login, signup } = useAuth();
  const [isSignup, setIsSignup] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<'buyer' | 'seller'>('buyer');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');

  const from = (location.state as { from?: string })?.from || '/dashboard';

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (isSignup) {
      if (!name.trim()) { setError('Please enter your name'); return; }
      const ok = signup(name, email, password, role);
      if (!ok) { setError('An account with this email already exists'); return; }
      navigate(from, { replace: true });
    } else {
      const ok = login(email, password);
      if (!ok) { setError('Invalid email or password'); return; }
      navigate(from, { replace: true });
    }
  };

  return (
    <main className="min-h-screen bg-forest flex items-center justify-center px-6">
      <div className="w-full max-w-[420px]">
        <div className="text-center mb-8">
          <Link to="/" className="font-display text-[28px] text-cream-bold">TradeLink</Link>
          <p className="font-body text-sage mt-2 text-[14px]">
            {isSignup ? 'Create your account to start trading' : 'Sign in to your account'}
          </p>
        </div>

        <div className="glass-panel rounded-xl p-8">
          {error && (
            <div className="mb-4 p-3 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400 font-body text-[13px]">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {isSignup && (
              <div>
                <label className="block font-body text-[12px] uppercase tracking-[0.08em] text-sage mb-1.5">Full Name</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="John Doe"
                  className="w-full bg-forest-dark/60 border border-cream/[0.08] rounded-lg px-4 py-3 font-body text-[14px] text-cream placeholder:text-sage/50 focus:outline-none focus:border-gold/50 transition-colors"
                />
              </div>
            )}

            <div>
              <label className="block font-body text-[12px] uppercase tracking-[0.08em] text-sage mb-1.5">Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="w-full bg-forest-dark/60 border border-cream/[0.08] rounded-lg px-4 py-3 font-body text-[14px] text-cream placeholder:text-sage/50 focus:outline-none focus:border-gold/50 transition-colors"
              />
            </div>

            <div>
              <label className="block font-body text-[12px] uppercase tracking-[0.08em] text-sage mb-1.5">Password</label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-forest-dark/60 border border-cream/[0.08] rounded-lg px-4 py-3 pr-10 font-body text-[14px] text-cream placeholder:text-sage/50 focus:outline-none focus:border-gold/50 transition-colors"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-sage hover:text-cream transition-colors"
                >
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            {isSignup && (
              <div>
                <label className="block font-body text-[12px] uppercase tracking-[0.08em] text-sage mb-1.5">I am a</label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setRole('buyer')}
                    className={`py-3 rounded-lg font-body text-[13px] font-medium border transition-all ${
                      role === 'buyer'
                        ? 'bg-emerald border-emerald text-cream-bold'
                        : 'bg-forest-dark/40 border-cream/[0.08] text-sage hover:border-cream/30'
                    }`}
                  >
                    Buyer
                  </button>
                  <button
                    type="button"
                    onClick={() => setRole('seller')}
                    className={`py-3 rounded-lg font-body text-[13px] font-medium border transition-all ${
                      role === 'seller'
                        ? 'bg-emerald border-emerald text-cream-bold'
                        : 'bg-forest-dark/40 border-cream/[0.08] text-sage hover:border-cream/30'
                    }`}
                  >
                    Seller
                  </button>
                </div>
              </div>
            )}

            <button
              type="submit"
              className="w-full font-body font-semibold text-cream-bold bg-emerald py-3.5 rounded-lg text-[15px] hover:bg-emerald-light hover:shadow-btn-glow transition-all duration-300 flex items-center justify-center gap-2 mt-2"
            >
              {isSignup ? <UserPlus size={18} /> : <LogIn size={18} />}
              {isSignup ? 'Create Account' : 'Sign In'}
            </button>
          </form>

          <div className="mt-6 text-center">
            <button
              onClick={() => { setIsSignup(!isSignup); setError(''); }}
              className="font-body text-[14px] text-sage hover:text-gold transition-colors"
            >
              {isSignup ? 'Already have an account? Sign In' : "Don't have an account? Sign Up"}
            </button>
          </div>

          {!isSignup && (
            <div className="mt-4 p-3 rounded-lg bg-gold/5 border border-gold/10">
              <p className="font-body text-[11px] text-gold/70 text-center uppercase tracking-[0.06em]">Demo Credentials</p>
              <div className="flex justify-between mt-1">
                <button
                  type="button"
                  onClick={() => { setEmail('buyer@demo.com'); setPassword('demo123'); }}
                  className="font-body text-[11px] text-sage hover:text-cream transition-colors"
                >
                  buyer@demo.com
                </button>
                <button
                  type="button"
                  onClick={() => { setEmail('seller@demo.com'); setPassword('demo123'); }}
                  className="font-body text-[11px] text-sage hover:text-cream transition-colors"
                >
                  seller@demo.com
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </main>
  );
}
