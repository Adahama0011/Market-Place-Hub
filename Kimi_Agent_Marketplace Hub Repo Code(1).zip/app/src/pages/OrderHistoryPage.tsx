import { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { getOrdersForUser } from '../data/orders';
import { STATUS_LABELS, STATUS_COLORS } from '../data/orders';
import type { Order, OrderStatus } from '../data/orders';
import Footer from '../sections/Footer';
import {
  Search, Filter, ChevronRight, Package, ShoppingBag,
  CheckCircle, XCircle, AlertTriangle
} from 'lucide-react';

type FilterStatus = 'all' | OrderStatus;

const FILTERS: { key: FilterStatus; label: string; count?: (orders: Order[]) => number }[] = [
  { key: 'all', label: 'All Orders', count: (o) => o.length },
  { key: 'pending', label: 'Pending', count: (o) => o.filter((x) => x.status === 'pending').length },
  { key: 'processing', label: 'Processing', count: (o) => o.filter((x) => ['processing', 'confirmed'].includes(x.status)).length },
  { key: 'shipped', label: 'Shipped', count: (o) => o.filter((x) => ['shipped', 'in_transit'].includes(x.status)).length },
  { key: 'delivered', label: 'Delivered', count: (o) => o.filter((x) => x.status === 'delivered').length },
  { key: 'completed', label: 'Completed', count: (o) => o.filter((x) => x.status === 'completed').length },
  { key: 'cancelled', label: 'Cancelled', count: (o) => o.filter((x) => x.status === 'cancelled').length },
  { key: 'disputed', label: 'Disputed', count: (o) => o.filter((x) => x.status === 'disputed').length },
];

export default function OrderHistoryPage() {
  const { user } = useAuth();
  const orders = useMemo(() => {
    if (!user) return [];
    return getOrdersForUser(user.id, user.email);
  }, [user]);

  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<FilterStatus>('all');
  const [sortBy, setSortBy] = useState<'recent' | 'oldest' | 'highest' | 'lowest'>('recent');

  const filtered = useMemo(() => {
    let result = [...orders];

    if (filter !== 'all') {
      if (filter === 'processing') result = result.filter((o) => ['processing', 'confirmed'].includes(o.status));
      else if (filter === 'shipped') result = result.filter((o) => ['shipped', 'in_transit'].includes(o.status));
      else result = result.filter((o) => o.status === filter);
    }

    if (search.trim()) {
      const q = search.toLowerCase();
      result = result.filter(
        (o) =>
          o.id.toLowerCase().includes(q) ||
          o.deal.title.toLowerCase().includes(q) ||
          o.sellerName.toLowerCase().includes(q)
      );
    }

    switch (sortBy) {
      case 'oldest': result.sort((a, b) => +new Date(a.createdAt) - +new Date(b.createdAt)); break;
      case 'highest': result.sort((a, b) => b.total - a.total); break;
      case 'lowest': result.sort((a, b) => a.total - b.total); break;
      default: result.sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt)); break;
    }

    return result;
  }, [orders, filter, search, sortBy]);

  return (
    <main className="relative z-10 bg-forest min-h-screen">
      {/* Header */}
      <section className="pt-[100px] pb-6 px-6">
        <div className="max-w-[1280px] mx-auto">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h1 className="font-display text-cream-bold text-[28px]">Order History</h1>
              <p className="font-body text-[14px] text-sage mt-1">{orders.length} total orders</p>
            </div>
            <Link
              to="/"
              className="font-body text-[14px] font-medium text-cream-bold bg-emerald px-5 py-2.5 rounded-lg hover:bg-emerald-light transition-all flex items-center gap-2 self-start"
            >
              <ShoppingBag size={16} /> Browse Deals
            </Link>
          </div>
        </div>
      </section>

      {/* Filters */}
      <section className="px-6 pb-6">
        <div className="max-w-[1280px] mx-auto">
          {/* Search */}
          <div className="flex flex-col sm:flex-row gap-3 mb-4">
            <div className="relative flex-1">
              <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-sage" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search by order ID, item, or seller..."
                className="w-full bg-forest-dark/60 border border-cream/[0.08] rounded-lg pl-10 pr-4 py-3 font-body text-[14px] text-cream placeholder:text-sage/50 focus:outline-none focus:border-gold/50 transition-colors"
              />
            </div>
            <div className="flex items-center gap-2">
              <Filter size={16} className="text-sage" />
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
                className="bg-forest-dark/60 border border-cream/[0.08] rounded-lg px-4 py-3 font-body text-[14px] text-cream focus:outline-none focus:border-gold/50 transition-colors cursor-pointer"
              >
                <option value="recent">Most Recent</option>
                <option value="oldest">Oldest First</option>
                <option value="highest">Highest Price</option>
                <option value="lowest">Lowest Price</option>
              </select>
            </div>
          </div>

          {/* Filter tabs */}
          <div className="flex gap-2 overflow-x-auto pb-2">
            {FILTERS.map((f) => (
              <button
                key={f.key}
                onClick={() => setFilter(f.key)}
                className={`flex-shrink-0 font-body text-[13px] font-medium px-4 py-2 rounded-lg border transition-all ${
                  filter === f.key
                    ? 'bg-emerald border-emerald text-cream-bold'
                    : 'bg-forest-dark/40 border-cream/[0.06] text-sage hover:border-cream/20 hover:text-cream'
                }`}
              >
                {f.label}
                {f.count && (
                  <span className={`ml-1.5 font-mono text-[11px] ${filter === f.key ? 'text-cream/70' : 'text-sage/60'}`}>
                    {f.count(orders)}
                  </span>
                )}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Orders List */}
      <section className="px-6 pb-[120px]">
        <div className="max-w-[1280px] mx-auto">
          {filtered.length === 0 ? (
            <div className="glass-panel rounded-xl p-16 text-center">
              <Package size={48} className="text-sage/20 mx-auto mb-4" />
              <h3 className="font-body text-[18px] font-semibold text-cream">No orders found</h3>
              <p className="font-body text-[14px] text-sage mt-2">
                {search ? 'Try adjusting your search or filters' : 'Start browsing to place your first order'}
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {filtered.map((order) => (
                <OrderHistoryRow key={order.id} order={order} />
              ))}
            </div>
          )}
        </div>
      </section>

      <Footer />
    </main>
  );
}

function OrderHistoryRow({ order }: { order: Order }) {
  const statusColor = STATUS_COLORS[order.status];
  const statusLabel = STATUS_LABELS[order.status];
  const isCompleted = order.status === 'completed';
  const isCancelled = order.status === 'cancelled';
  const isDisputed = order.status === 'disputed';

  return (
    <Link
      to={`/order/${order.id}`}
      className="glass-panel rounded-xl p-5 flex flex-col sm:flex-row gap-4 group hover:border-gold/20 transition-all"
    >
      {/* Image */}
      <div className="w-20 h-20 rounded-lg overflow-hidden flex-shrink-0 self-start">
        <img src={order.deal.image} alt="" className="w-full h-full object-cover" />
      </div>

      {/* Info */}
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="font-mono text-[12px] text-sage">{order.id}</span>
          <span
            className="font-body text-[11px] uppercase tracking-[0.06em] px-2 py-0.5 rounded font-medium"
            style={{ background: `${statusColor}20`, color: statusColor }}
          >
            {statusLabel}
          </span>
          {isCompleted && <CheckCircle size={14} className="text-emerald" />}
          {isCancelled && <XCircle size={14} className="text-red-400" />}
          {isDisputed && <AlertTriangle size={14} className="text-gold" />}
        </div>
        <h3 className="font-body text-[15px] font-semibold text-cream mt-1 line-clamp-1 group-hover:text-cream-bold transition-colors">
          {order.deal.title}
        </h3>
        <div className="flex items-center gap-4 mt-1.5">
          <span className="font-body text-[12px] text-sage">{order.sellerName}</span>
          <span className="font-body text-[12px] text-sage">Qty: {order.quantity}</span>
          <span className="font-body text-[12px] text-sage">{new Date(order.createdAt).toLocaleDateString()}</span>
        </div>
      </div>

      {/* Price & Arrow */}
      <div className="flex items-center gap-4 flex-shrink-0 self-end sm:self-center">
        <div className="text-right">
          <span className="font-mono text-[18px] font-bold text-gold">${order.total.toLocaleString()}</span>
          {order.savings > 0 && (
            <p className="font-body text-[11px] text-emerald">Saved ${(order.savings * order.quantity).toLocaleString()}</p>
          )}
        </div>
        <ChevronRight size={18} className="text-sage group-hover:text-gold transition-colors" />
      </div>
    </Link>
  );
}
