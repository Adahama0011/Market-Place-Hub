import { useParams, Link, useNavigate } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { getOrderById, updateOrderStatus, STATUS_LABELS, STATUS_COLORS } from '../data/orders';
import type { Order, OrderStatus } from '../data/orders';
import Footer from '../sections/Footer';
import {
  ChevronRight, Package, MapPin, Calendar, Clock,
  Truck, Shield, CheckCircle, AlertCircle, ChevronLeft
} from 'lucide-react';

const TIMELINE_STEPS: { status: OrderStatus; label: string; icon: React.ReactNode }[] = [
  { status: 'pending', label: 'Order Placed', icon: <Clock size={16} /> },
  { status: 'processing', label: 'Processing', icon: <Package size={16} /> },
  { status: 'confirmed', label: 'Confirmed', icon: <CheckCircle size={16} /> },
  { status: 'shipped', label: 'Shipped', icon: <Truck size={16} /> },
  { status: 'in_transit', label: 'In Transit', icon: <MapPin size={16} /> },
  { status: 'delivered', label: 'Delivered', icon: <CheckCircle size={16} /> },
  { status: 'completed', label: 'Completed', icon: <CheckCircle size={16} /> },
];

export default function OrderTrackPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [order, setOrder] = useState<Order | null>(null);
  const [simulating, setSimulating] = useState(false);

  useEffect(() => {
    if (id) {
      const o = getOrderById(id);
      setOrder(o);
    }
  }, [id]);

  const simulateNextStep = () => {
    if (!order || simulating) return;
    const flow: OrderStatus[] = ['pending', 'processing', 'confirmed', 'shipped', 'in_transit', 'delivered', 'completed'];
    const currentIdx = flow.indexOf(order.status);
    if (currentIdx >= flow.length - 1) return;

    setSimulating(true);
    const nextStatus = flow[currentIdx + 1];
    const descriptions: Record<string, string> = {
      processing: 'Seller is reviewing your offer and preparing the item.',
      confirmed: 'Seller has accepted your offer and confirmed the order.',
      shipped: `Item has been shipped. Tracking: ${order.trackingNumber || 'TRK-' + Math.random().toString(36).substring(2, 10).toUpperCase()}`,
      in_transit: 'Package is on the way to your address.',
      delivered: 'Package has been delivered. Please inspect and confirm.',
      completed: 'Order completed successfully. Funds released to seller.',
    };

    setTimeout(() => {
      const updated = updateOrderStatus(order.id, nextStatus, descriptions[nextStatus]);
      if (updated) setOrder(updated);
      setSimulating(false);
    }, 800);
  };

  if (!order) {
    return (
      <div className="min-h-screen bg-forest flex items-center justify-center">
        <div className="text-center">
          <h1 className="font-display text-cream text-3xl">Order not found</h1>
          <Link to="/orders" className="font-body text-gold mt-4 inline-block hover:underline">&larr; Back to orders</Link>
        </div>
      </div>
    );
  }

  const currentStepIdx = TIMELINE_STEPS.findIndex((s) => s.status === order.status);
  const isTerminal = ['completed', 'cancelled', 'disputed'].includes(order.status);
  const isDelivered = order.status === 'delivered';

  return (
    <main className="relative z-10 bg-forest min-h-screen">
      {/* Header */}
      <section className="pt-[100px] pb-6 px-6">
        <div className="max-w-[900px] mx-auto">
          <button
            onClick={() => navigate(-1)}
            className="flex items-center gap-1 font-body text-[13px] text-sage hover:text-cream transition-colors mb-4"
          >
            <ChevronLeft size={14} /> Back
          </button>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-3">
                <h1 className="font-display text-cream-bold text-[24px]">{order.id}</h1>
                <span
                  className="font-body text-[11px] uppercase tracking-[0.06em] px-2.5 py-1 rounded font-medium"
                  style={{ background: `${STATUS_COLORS[order.status]}20`, color: STATUS_COLORS[order.status] }}
                >
                  {STATUS_LABELS[order.status]}
                </span>
              </div>
              <p className="font-body text-[13px] text-sage mt-1">Placed on {new Date(order.createdAt).toLocaleDateString('en-US', { dateStyle: 'long' })}</p>
            </div>
            {!isTerminal && (
              <button
                onClick={simulateNextStep}
                disabled={simulating}
                className="font-body text-[13px] font-medium text-forest-dark bg-gold px-5 py-2.5 rounded-lg hover:bg-gold-amber transition-all disabled:opacity-50 flex items-center gap-2"
              >
                {simulating ? 'Updating...' : 'Simulate Next Step'}
                <ChevronRight size={14} />
              </button>
            )}
          </div>
        </div>
      </section>

      <section className="px-6 pb-[80px]">
        <div className="max-w-[900px] mx-auto grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main - Timeline */}
          <div className="lg:col-span-2 space-y-6">
            {/* Progress Overview */}
            <div className="glass-panel rounded-xl p-6">
              <h2 className="font-body text-[14px] uppercase tracking-[0.08em] text-sage mb-6">Order Progress</h2>
              <div className="relative">
                {/* Vertical line */}
                <div className="absolute left-[19px] top-0 bottom-0 w-[2px] bg-cream/[0.06]" />
                <div className="space-y-0">
                  {TIMELINE_STEPS.map((step, idx) => {
                    const isCompleted = idx <= currentStepIdx;
                    const isCurrent = idx === currentStepIdx;
                    const event = order.timeline.find((e) => e.status === step.status);

                    return (
                      <div key={step.status} className={`relative flex gap-4 pb-8 ${isCurrent ? '' : ''}`}>
                        {/* Dot */}
                        <div className="relative z-10 flex-shrink-0">
                          <div
                            className={`w-10 h-10 rounded-full flex items-center justify-center border-2 transition-all ${
                              isCompleted
                                ? 'bg-emerald border-emerald text-cream-bold'
                                : isCurrent
                                ? 'bg-gold/20 border-gold text-gold'
                                : 'bg-forest-dark border-cream/[0.08] text-sage'
                            }`}
                          >
                            {isCompleted && !isCurrent ? <CheckCircle size={16} /> : step.icon}
                          </div>
                        </div>
                        {/* Content */}
                        <div className="flex-1 pt-1.5">
                          <div className="flex items-center gap-2">
                            <span className={`font-body text-[14px] font-medium ${isCompleted || isCurrent ? 'text-cream' : 'text-sage'}`}>
                              {step.label}
                            </span>
                            {isCurrent && (
                              <span className="font-body text-[10px] uppercase tracking-[0.08em] text-gold bg-gold/10 px-2 py-0.5 rounded">Current</span>
                            )}
                          </div>
                          {event && (
                            <p className="font-body text-[13px] text-sage mt-1">{event.description}</p>
                          )}
                          {event && (
                            <p className="font-body text-[11px] text-sage/60 mt-1">
                              {new Date(event.timestamp).toLocaleString('en-US', { dateStyle: 'medium', timeStyle: 'short' })}
                            </p>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Timeline Detail Log */}
            <div className="glass-panel rounded-xl p-6">
              <h2 className="font-body text-[14px] uppercase tracking-[0.08em] text-sage mb-4">Activity Log</h2>
              <div className="space-y-3">
                {order.timeline.slice().reverse().map((event, idx) => (
                  <div key={idx} className="flex gap-3 p-3 rounded-lg bg-forest-dark/30">
                    <div className="w-2 h-2 rounded-full mt-1.5 flex-shrink-0" style={{ background: STATUS_COLORS[event.status] }} />
                    <div>
                      <p className="font-body text-[13px] text-cream font-medium">{event.label}</p>
                      <p className="font-body text-[12px] text-sage mt-0.5">{event.description}</p>
                      <p className="font-body text-[11px] text-sage/50 mt-0.5">
                        {new Date(event.timestamp).toLocaleString('en-US', { dateStyle: 'medium', timeStyle: 'short' })}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar - Order Info */}
          <div className="space-y-6">
            {/* Deal Summary */}
            <div className="glass-panel rounded-xl p-5">
              <h3 className="font-body text-[14px] uppercase tracking-[0.08em] text-sage mb-4">Order Summary</h3>
              <div className="flex gap-3 mb-4">
                <div className="w-14 h-14 rounded-lg overflow-hidden flex-shrink-0">
                  <img src={order.deal.image} alt="" className="w-full h-full object-cover" />
                </div>
                <div>
                  <p className="font-body text-[14px] text-cream font-medium line-clamp-2">{order.deal.title}</p>
                  <p className="font-body text-[12px] text-sage mt-1">{order.sellerName}</p>
                </div>
              </div>
              <div className="space-y-2 border-t border-cream/[0.06] pt-3">
                <div className="flex justify-between font-body text-[13px]">
                  <span className="text-sage">Price</span>
                  <span className="text-cream">${order.offeredPrice.toLocaleString()}</span>
                </div>
                <div className="flex justify-between font-body text-[13px]">
                  <span className="text-sage">Qty</span>
                  <span className="text-cream">{order.quantity}</span>
                </div>
                <div className="flex justify-between font-body text-[13px]">
                  <span className="text-sage">Escrow</span>
                  <span className="text-cream">${Math.round(order.escrowAmount * 0.025).toLocaleString()}</span>
                </div>
                <div className="flex justify-between font-body text-[15px] font-semibold border-t border-cream/[0.06] pt-2">
                  <span className="text-cream-bold">Total</span>
                  <span className="font-mono text-gold">${order.total.toLocaleString()}</span>
                </div>
              </div>
            </div>

            {/* Shipping Info */}
            <div className="glass-panel rounded-xl p-5">
              <h3 className="font-body text-[14px] uppercase tracking-[0.08em] text-sage mb-4">Shipping</h3>
              {order.shippingAddress ? (
                <div className="flex gap-2">
                  <MapPin size={16} className="text-gold flex-shrink-0 mt-0.5" />
                  <p className="font-body text-[13px] text-cream">{order.shippingAddress}</p>
                </div>
              ) : (
                <p className="font-body text-[13px] text-sage">No shipping address provided</p>
              )}
              {order.trackingNumber && (
                <div className="mt-3 flex gap-2">
                  <Truck size={16} className="text-emerald flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-body text-[12px] text-sage">Tracking Number</p>
                    <p className="font-mono text-[13px] text-cream">{order.trackingNumber}</p>
                  </div>
                </div>
              )}
              {order.estimatedDelivery && (
                <div className="mt-3 flex gap-2">
                  <Calendar size={16} className="text-gold flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-body text-[12px] text-sage">Estimated Delivery</p>
                    <p className="font-body text-[13px] text-cream">{order.estimatedDelivery}</p>
                  </div>
                </div>
              )}
            </div>

            {/* Escrow Status */}
            <div className="glass-panel rounded-xl p-5">
              <div className="flex items-center gap-2 mb-2">
                <Shield size={16} className="text-emerald" />
                <h3 className="font-body text-[14px] uppercase tracking-[0.08em] text-sage">Escrow Status</h3>
              </div>
              <p className="font-body text-[13px] text-cream">
                ${order.escrowAmount.toLocaleString()} held securely
              </p>
              <p className="font-body text-[12px] text-sage mt-1">
                {order.status === 'completed'
                  ? 'Funds released to seller'
                  : 'Funds will be released upon delivery confirmation'}
              </p>
            </div>

            {/* Actions */}
            {isDelivered && (
              <div className="glass-panel rounded-xl p-5 border-emerald/30">
                <div className="flex items-center gap-2 mb-3">
                  <AlertCircle size={16} className="text-gold" />
                  <h3 className="font-body text-[14px] font-semibold text-cream">Confirm Receipt</h3>
                </div>
                <p className="font-body text-[12px] text-sage mb-3">Have you received and inspected your item?</p>
                <button
                  onClick={() => {
                    const updated = updateOrderStatus(order.id, 'completed', 'Buyer confirmed receipt and satisfaction. Funds released to seller.');
                    if (updated) setOrder(updated);
                  }}
                  className="w-full font-body font-semibold text-cream-bold bg-emerald py-3 rounded-lg text-[14px] hover:bg-emerald-light transition-all"
                >
                  Confirm & Release Funds
                </button>
              </div>
            )}
          </div>
        </div>
      </section>

      <Footer />
    </main>
  );
}
