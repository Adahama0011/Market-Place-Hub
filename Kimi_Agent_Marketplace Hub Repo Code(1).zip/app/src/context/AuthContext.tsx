import { createContext, useContext, useState, useCallback, useEffect, type ReactNode } from 'react';

export interface User {
  id: string;
  name: string;
  email: string;
  avatar: string;
  role: 'buyer' | 'seller';
  joinedAt: string;
}

interface AuthContextType {
  user: User | null;
  isLoggedIn: boolean;
  login: (email: string, password: string) => boolean;
  signup: (name: string, email: string, password: string, role: 'buyer' | 'seller') => boolean;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

const AVATARS = [
  '/images/avatar-1.jpg',
  '/images/avatar-2.jpg',
  '/images/avatar-3.jpg',
];

function getUsers(): Record<string, { name: string; email: string; password: string; role: 'buyer' | 'seller'; avatar: string }> {
  try {
    return JSON.parse(localStorage.getItem('tradelink_users') || '{}');
  } catch {
    return {};
  }
}

function saveUsers(users: Record<string, unknown>) {
  localStorage.setItem('tradelink_users', JSON.stringify(users));
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(() => {
    try {
      const saved = localStorage.getItem('tradelink_current_user');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  useEffect(() => {
    // Seed demo accounts if none exist
    const users = getUsers();
    if (Object.keys(users).length === 0) {
      const demoUsers: Record<string, { name: string; email: string; password: string; role: 'buyer' | 'seller'; avatar: string }> = {
        'buyer@demo.com': {
          name: 'Alex Johnson',
          email: 'buyer@demo.com',
          password: 'demo123',
          role: 'buyer',
          avatar: '/images/avatar-1.jpg',
        },
        'seller@demo.com': {
          name: 'Sarah Chen',
          email: 'seller@demo.com',
          password: 'demo123',
          role: 'seller',
          avatar: '/images/avatar-2.jpg',
        },
      };
      saveUsers(demoUsers);
    }
  }, []);

  const login = useCallback((email: string, password: string): boolean => {
    const users = getUsers();
    const found = users[email.toLowerCase()];
    if (found && found.password === password) {
      const userData: User = {
        id: btoa(email),
        name: found.name,
        email: found.email,
        avatar: found.avatar,
        role: found.role,
        joinedAt: new Date().toISOString(),
      };
      setUser(userData);
      localStorage.setItem('tradelink_current_user', JSON.stringify(userData));
      return true;
    }
    return false;
  }, []);

  const signup = useCallback((name: string, email: string, password: string, role: 'buyer' | 'seller'): boolean => {
    const users = getUsers();
    const key = email.toLowerCase();
    if (users[key]) return false;

    users[key] = {
      name,
      email: key,
      password,
      role,
      avatar: AVATARS[Math.floor(Math.random() * AVATARS.length)],
    };
    saveUsers(users);

    const userData: User = {
      id: btoa(key),
      name,
      email: key,
      avatar: users[key].avatar,
      role,
      joinedAt: new Date().toISOString(),
    };
    setUser(userData);
    localStorage.setItem('tradelink_current_user', JSON.stringify(userData));
    return true;
  }, []);

  const logout = useCallback(() => {
    setUser(null);
    localStorage.removeItem('tradelink_current_user');
  }, []);

  return (
    <AuthContext.Provider value={{ user, isLoggedIn: !!user, login, signup, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
