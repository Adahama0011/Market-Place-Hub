import { Routes, Route } from 'react-router-dom';
import Navbar from './sections/Navbar';
import HomePage from './pages/HomePage';
import DealDetailPage from './pages/DealDetailPage';
import LoginPage from './pages/LoginPage';
import DashboardPage from './pages/DashboardPage';
import OrderCreatePage from './pages/OrderCreatePage';
import OrderTrackPage from './pages/OrderTrackPage';
import OrderHistoryPage from './pages/OrderHistoryPage';
import ProtectedRoute from './components/ProtectedRoute';

export default function App() {
  return (
    <div className="min-h-screen bg-forest">
      <Navbar />
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/deal/:id" element={<DealDetailPage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/dashboard" element={<ProtectedRoute><DashboardPage /></ProtectedRoute>} />
        <Route path="/checkout/:id" element={<ProtectedRoute><OrderCreatePage /></ProtectedRoute>} />
        <Route path="/order/:id" element={<ProtectedRoute><OrderTrackPage /></ProtectedRoute>} />
        <Route path="/orders" element={<ProtectedRoute><OrderHistoryPage /></ProtectedRoute>} />
      </Routes>
    </div>
  );
}
