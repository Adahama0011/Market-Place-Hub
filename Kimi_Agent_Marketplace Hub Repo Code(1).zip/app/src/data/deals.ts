export interface Deal {
  id: string;
  title: string;
  category: string;
  subcategory?: string;
  price: number;
  originalPrice: number;
  image: string;
  seller: {
    name: string;
    avatar: string;
    rating: number;
    reviews: number;
    verified: boolean;
  };
  condition?: string;
  location?: string;
  listedAgo?: string;
  views?: number;
  description?: string;
  specs?: { label: string; value: string }[];
}

export const deals: Deal[] = [
  {
    id: "1",
    title: "MacBook Pro 16-inch M3 Max — 1TB SSD, 36GB RAM",
    category: "Electronics",
    subcategory: "Laptops",
    price: 2499,
    originalPrice: 3199,
    image: "/images/deal-macbook.jpg",
    seller: { name: "TechVault Resale", avatar: "/images/avatar-1.jpg", rating: 4.9, reviews: 127, verified: true },
    condition: "Like New",
    location: "Austin, TX",
    listedAgo: "2 days ago",
    views: 342,
    description: "Barely used MacBook Pro 16-inch with the powerful M3 Max chip. Only 12 battery cycles. Includes original box, charger, and AppleCare+ through 2026. Perfect for creative professionals and power users. No scratches, dents, or defects. Screen protector applied since day one.",
    specs: [
      { label: "Processor", value: "Apple M3 Max (16-core CPU, 40-core GPU)" },
      { label: "Memory", value: "36GB Unified Memory" },
      { label: "Storage", value: "1TB SSD" },
      { label: "Display", value: '16.2" Liquid Retina XDR (3456x2234)' },
      { label: "Battery Cycles", value: "12" },
      { label: "Warranty", value: "AppleCare+ until Dec 2026" },
    ],
  },
  {
    id: "2",
    title: "Vintage Leica M6 TTL Film Camera with 35mm Lens",
    category: "Electronics",
    subcategory: "Cameras",
    price: 3200,
    originalPrice: 4500,
    image: "/images/deal-camera.jpg",
    seller: { name: "Classic Optics Co.", avatar: "/images/avatar-2.jpg", rating: 4.8, reviews: 89, verified: true },
    condition: "Excellent",
    location: "Portland, OR",
    listedAgo: "5 days ago",
    views: 518,
    description: "Beautifully maintained Leica M6 TTL in black chrome finish. Recently CLA'd by Sherry Krauter. Light meter is accurate, shutter speeds are spot-on. Comes with Leica Summicron 35mm f/2 lens. A true collector's piece that shoots as good as it looks.",
  },
  {
    id: "3",
    title: "Modern Cognac Leather 3-Seater Sofa — Mid-Century Style",
    category: "Real Estate",
    subcategory: "Furniture",
    price: 1899,
    originalPrice: 2800,
    image: "/images/deal-sofa.jpg",
    seller: { name: "Luxe Living Co.", avatar: "/images/avatar-3.jpg", rating: 4.7, reviews: 203, verified: true },
    condition: "Like New",
    location: "Brooklyn, NY",
    listedAgo: "1 week ago",
    views: 267,
    description: "Stunning cognac leather sofa in impeccable condition. Full-grain Italian leather that develops a beautiful patina over time. Solid walnut legs. Seat cushions are high-density foam wrapped in down for the perfect balance of support and comfort.",
  },
  {
    id: "4",
    title: "VanMoof S5 Electric City Bike — Matte Black",
    category: "Vehicles",
    subcategory: "Bicycles",
    price: 2800,
    originalPrice: 3498,
    image: "/images/deal-bike.jpg",
    seller: { name: "Urban Cycles", avatar: "/images/avatar-1.jpg", rating: 4.9, reviews: 56, verified: false },
    condition: "Good",
    location: "Seattle, WA",
    listedAgo: "3 days ago",
    views: 891,
    description: "The ultimate city commuter. 60-mile range, automatic electronic shifting, integrated lights, and theft defense with built-in alarm and tracking. Minor cosmetic wear on the frame but mechanically perfect. Recently serviced at authorized dealer.",
  },
  {
    id: "5",
    title: "NOMOS Glashutte Minimalist Gold Dial Watch",
    category: "Fashion",
    subcategory: "Watches",
    price: 1850,
    originalPrice: 2400,
    image: "/images/deal-watch.jpg",
    seller: { name: "Timepiece Traders", avatar: "/images/avatar-2.jpg", rating: 5.0, reviews: 34, verified: true },
    condition: "Like New",
    location: "Chicago, IL",
    listedAgo: "4 days ago",
    views: 423,
    description: "Exquisite German engineering meets Bauhaus design. In-house Alpha manual-wind movement. Sapphire crystal front and back. Black Horween shell cordovan strap. Worn only a handful of times. Complete with box, papers, and warranty card.",
  },
  {
    id: "6",
    title: "Fully Jarvis Standing Desk — Walnut Top, 60x30",
    category: "Electronics",
    subcategory: "Office",
    price: 549,
    originalPrice: 849,
    image: "/images/deal-desk.jpg",
    seller: { name: "Workspace Deals", avatar: "/images/avatar-3.jpg", rating: 4.6, reviews: 312, verified: true },
    condition: "Very Good",
    location: "Denver, CO",
    listedAgo: "1 day ago",
    views: 156,
    description: "Premium sit-stand desk with beautiful walnut veneer top. Dual-motor frame supports up to 350 lbs. Programmable memory presets. Cable management tray included. Minor surface marks that are barely visible. A game-changer for your home office.",
  },
  {
    id: "7",
    title: "Limited Edition Forest Green Sneakers — Size 10.5",
    category: "Fashion",
    subcategory: "Sneakers",
    price: 220,
    originalPrice: 350,
    image: "/images/deal-sneakers.jpg",
    seller: { name: "SneakerVault", avatar: "/images/avatar-1.jpg", rating: 4.8, reviews: 445, verified: true },
    condition: "New",
    location: "Los Angeles, CA",
    listedAgo: "6 hours ago",
    views: 734,
    description: "Exclusive collaboration release. Premium materials with forest green suede and white leather. Never worn, deadstock condition. Comes with original box, extra laces, and dust bag. These won't last long at this price.",
  },
  {
    id: "8",
    title: "Sonos Era 100 Smart Speaker — Spatial Audio",
    category: "Electronics",
    subcategory: "Audio",
    price: 199,
    originalPrice: 249,
    image: "/images/deal-speaker.jpg",
    seller: { name: "AudioDepot", avatar: "/images/avatar-2.jpg", rating: 4.7, reviews: 178, verified: false },
    condition: "Very Good",
    location: "Miami, FL",
    listedAgo: "3 days ago",
    views: 289,
    description: "Immersive spatial audio in a compact form factor. Streams over WiFi and Bluetooth. Works with Apple AirPlay 2, Alexa, and Google Assistant. Trueplay tuning adapts sound to your room. Minor surface marks, fully functional.",
  },
];

export const categories = [
  { name: "Electronics", deals: 2847, icon: "smartphone" },
  { name: "Real Estate", deals: 1204, icon: "home" },
  { name: "Vehicles", deals: 3521, icon: "car" },
  { name: "Fashion", deals: 4109, icon: "shirt" },
  { name: "Industrial", deals: 892, icon: "cpu" },
  { name: "Services", deals: 5673, icon: "briefcase" },
];

export const trustedLogos = [
  "TechCorp",
  "GlobalMart",
  "VentureBuy",
  "SellFast",
  "DealFlow",
  "MarketPro",
];
