import type { Deal } from './deals';

export type OrderStatus =
  | 'pending'
  | 'processing'
  | 'confirmed'
  | 'shipped'
  | 'in_transit'
  | 'delivered'
  | 'completed'
  | 'cancelled'
  | 'disputed';

export interface Order {
  id: string;
  dealId: string;
  deal: Deal;
  buyerId: string;
  buyerName: string;
  buyerEmail: string;
  sellerId: string;
  sellerName: string;
  status: OrderStatus;
  offeredPrice: number;
  originalPrice: number;
  savings: number;
  quantity: number;
  total: number;
  escrowAmount: number;
  createdAt: string;
  updatedAt: string;
  timeline: OrderTimelineEvent[];
  shippingAddress?: string;
  trackingNumber?: string;
  estimatedDelivery?: string;
  notes?: string;
}

export interface OrderTimelineEvent {
  status: OrderStatus;
  label: string;
  description: string;
  timestamp: string;
  completed: boolean;
}

const STATUS_FLOW: OrderStatus[] = [
  'pending',
  'processing',
  'confirmed',
  'shipped',
  'in_transit',
  'delivered',
  'completed',
];

export const STATUS_LABELS: Record<OrderStatus, string> = {
  pending: 'Pending',
  processing: 'Processing',
  confirmed: 'Confirmed',
  shipped: 'Shipped',
  in_transit: 'In Transit',
  delivered: 'Delivered',
  completed: 'Completed',
  cancelled: 'Cancelled',
  disputed: 'Disputed',
};

export const STATUS_COLORS: Record<OrderStatus, string> = {
  pending: '#D4A843',
  processing: '#C9A84C',
  confirmed: '#2D5A3D',
  shipped: '#3A6B4D',
  in_transit: '#3A6B4D',
  delivered: '#2D5A3D',
  completed: '#2D5A3D',
  cancelled: '#8B4513',
  disputed: '#B22222',
};

function generateOrderId(): string {
  return 'ORD-' + Date.now().toString(36).toUpperCase() + '-' + Math.random().toString(36).substring(2, 6).toUpperCase();
}

function getOrdersStorage(): Order[] {
  try {
    return JSON.parse(localStorage.getItem('tradelink_orders') || '[]');
  } catch {
    return [];
  }
}

function saveOrdersStorage(orders: Order[]) {
  localStorage.setItem('tradelink_orders', JSON.stringify(orders));
}

export function createOrder(
  deal: Deal,
  buyerId: string,
  buyerName: string,
  buyerEmail: string,
  offeredPrice: number,
  quantity: number = 1,
  shippingAddress?: string,
  notes?: string
): Order {
  const now = new Date().toISOString();
  const order: Order = {
    id: generateOrderId(),
    dealId: deal.id,
    deal,
    buyerId,
    buyerName,
    buyerEmail,
    sellerId: deal.seller.name,
    sellerName: deal.seller.name,
    status: 'pending',
    offeredPrice,
    originalPrice: deal.price,
    savings: deal.price - offeredPrice,
    quantity,
    total: offeredPrice * quantity,
    escrowAmount: offeredPrice * quantity,
    createdAt: now,
    updatedAt: now,
    shippingAddress,
    notes,
    timeline: [
      {
        status: 'pending',
        label: 'Order Placed',
        description: `Offer of $${offeredPrice.toLocaleString()} submitted for ${deal.title}`,
        timestamp: now,
        completed: true,
      },
    ],
  };

  const orders = getOrdersStorage();
  orders.unshift(order);
  saveOrdersStorage(orders);
  return order;
}

export function getOrdersForUser(userId: string, userEmail: string): Order[] {
  const orders = getOrdersStorage();
  return orders.filter(
    (o) => o.buyerId === userId || o.buyerEmail === userEmail
  );
}

export function getOrderById(orderId: string): Order | null {
  const orders = getOrdersStorage();
  return orders.find((o) => o.id === orderId) || null;
}

export function updateOrderStatus(orderId: string, newStatus: OrderStatus, description?: string): Order | null {
  const orders = getOrdersStorage();
  const idx = orders.findIndex((o) => o.id === orderId);
  if (idx === -1) return null;

  const order = orders[idx];
  const now = new Date().toISOString();

  order.status = newStatus;
  order.updatedAt = now;
  order.timeline.push({
    status: newStatus,
    label: STATUS_LABELS[newStatus],
    description: description || `Order status updated to ${STATUS_LABELS[newStatus]}`,
    timestamp: now,
    completed: true,
  });

  // Auto-fill tracking for shipped status
  if (newStatus === 'shipped' && !order.trackingNumber) {
    order.trackingNumber = 'TRK-' + Math.random().toString(36).substring(2, 10).toUpperCase();
  }

  // Auto-fill estimated delivery
  if (newStatus === 'confirmed' && !order.estimatedDelivery) {
    const est = new Date();
    est.setDate(est.getDate() + 5);
    order.estimatedDelivery = est.toISOString().split('T')[0];
  }

  orders[idx] = order;
  saveOrdersStorage(orders);
  return order;
}

export function getOrderProgressPercent(order: Order): number {
  const currentIdx = STATUS_FLOW.indexOf(order.status);
  if (currentIdx === -1) return 0;
  return Math.round((currentIdx / (STATUS_FLOW.length - 1)) * 100);
}

export { getOrdersStorage };
